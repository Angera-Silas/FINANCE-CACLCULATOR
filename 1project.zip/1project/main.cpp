#include <iostream>
#include "fv.h"
#include "pv.h"
#include "Present_Value.h"
#include "Future_Value.h"

using namespace std;

int main()
{
    int a;
    cout<<"____________________________CALCULATION TYPE____________________________________\n\n"<<endl;
    cout<<" 1. Compounding More than once in a year \n 2. Depreciating more than Once in a year \n 3. Future Value \n 4. Present Value\n\t";
    cin>>a;
    if(a==1)
        future_value Obj1;
    else if(a==2)
        present_amount Obj2;
    else if(a==3)
        Future_Value Obj3;
    else if(a==4)
        Present_Value Obj4;
    else
        cout<<"Invalid choice try again later"<<endl;
    return 0;
}
