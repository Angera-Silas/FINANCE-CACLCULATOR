#include "pv.h"
#include <cmath>
#include <iostream>
using namespace std;
present_amount::present_amount()
{
    cout << " CHOOSE HOW YOUR INVESTMENT IS COMPOUNDED\n 1. ANNUALLY\n 2. SEMI-ANNUALLY\n 3. QUATERLY\n 4. MONTHLY\n 5. WEEKLY\n 6. DAILY" << endl;
    cin >> opt;
    switch (opt)
    {
    case 1:
        m = 1;
        i = i / 100;
        pv = fv / (pow((1 + (i / m)), m * n));
        cout << "PRESENT VALUE = " << pv << endl;
        break;
    case 2:
        m = 2;
        i = i / 100;
        pv = pv / (pow((1 + (i / m)), m * n));
        cout << "PRESENT VALUE = " << pv << endl;
        break;
    case 3:
        m = 4;
        i = i / 100;
        pv = pv / (pow((1 + (i / m)), m * n));
        cout << "PRESENT VALUE = " << fv << endl;
        break;
    case 4:
        m = 12;
        i = i / 100;
        pv = pv / (pow((1 + (i / m)), m * n));
        cout << "PRESENT VALUE = " << pv << endl;
        break;
    case 5:
        m = 52;
        i = i / 100;
        pv = fv / (pow((1 + (i / m)), m * n));
        cout << "PRESENT VALUE = " << pv << endl;
        break;
    case 6:
        m = 365;
        i = i / 100;
        pv = fv / (pow((1 + (i / m)), m * n));
        cout << "PRESENT VALUE = " << pv << endl;
        break;
    default:
        cout << "INVALID CHOICE!" << endl;
        break;
    }
}

