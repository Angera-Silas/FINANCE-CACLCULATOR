#include "Future_Value.h"
#include <cmath>
#include <iostream>
using namespace std;

Future_Value::Future_Value()
{
    cout<<" 1. Future value \n 2. Future value of Ordinary annuity \n 3. Future Value of an Annuity due \n\t";
    cin>>v;
    if(v==1)
    {
        cout<<"Enter the Present Value(Pv)"<<endl;
        cin>>psv;
        cout<<"Enter interest rate(i)"<<endl;
        cin>>r;
        cout<<"Enter period(time)" <<endl;
        cin>>t;

        //this section is used to calculate future value
        ftv = psv * (pow(((r/100)+1),t));
        cout<<"Future Value is "<<ftv<<endl;
        //Calculaion of Ordinary annuity
    }
    else if(v==2)
    {
        cout<<"Enter the Present Value(Pv)"<<endl;
        cin>>psv;
        cout<<"Enter interest rate(i)"<<endl;
        cin>>r;
        cout<<"Enter period(time)" <<endl;
        cin>>t;

        b = pow(((r/100)+1),t);
        c = (b-1)/(r/100);
        ftv = c*psv;
        cout<<"The future value of Ordinary annuity is "<<ftv<<endl;
        //anuity due has an extra phase and therefore an (i+1) is added
    }
    else if(v==3)
    {
        cout<<"Enter the Present Value(Pv)"<<endl;
        cin>>psv;
        cout<<"Enter interest rate(i)"<<endl;
        cin>>r;
        cout<<"Enter period(time)" <<endl;
        cin>>t;
        r = r*0.01;
        b = pow((r+1),t);
        c = (b-1)/r;
        ftv = (r+1)*c*psv;
        cout<<"The future value of Annuity due is "<<ftv<<endl;
    }
    else
    {
        cout<<"Enter a valid choice"<<endl;
    }
}
