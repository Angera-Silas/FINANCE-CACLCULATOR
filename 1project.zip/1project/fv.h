#ifndef FV_H_INCLUDED
#define FV_H_INCLUDED
#include "cmp.h"
class future_value : public present_value, public interest_rate, public period
{
public:
    long fv,m;
    int opt;
    future_value();
private:

protected:

};



#endif // FV_H_INCLUDED
