#ifndef CMP_H_INCLUDED
#define CMP_H_INCLUDED
class present_value
{
public:
    double pv;
    //contructor of the class should have the same name as of the class
    //has no datatype
    present_value();
private:

protected:

};
class interest_rate
{
public:
    double i;
    interest_rate();
private:

protected:

};
class period
{
public:
    double n;
    period();
private:

protected:

};
#endif // CMP_H_INCLUDED
