#ifndef DEP_H_INCLUDED
#define DEP_H_INCLUDED
class future_amount
{
public:
    double fv;
    //contructor of the class should have the same name as of the class
    //has no datatype
    future_amount();
private:

protected:

};
class interest_rat
{
public:
    double i;
    interest_rat();
private:

protected:

};
class periods
{
public:
    double n;
    periods();
private:

protected:

};

#endif // DEP_H_INCLUDED
