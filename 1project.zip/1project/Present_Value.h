#ifndef PRESENT_VALUE_H_INCLUDED
#define PRESENT_VALUE_H_INCLUDED
class Present_Value
{
public:
    long fcv;
    int s,N;
    float h,f,d,e,g,I;
    long ptv;
    Present_Value();
private:

protected:

};


#endif // PRESENT_VALUE_H_INCLUDED
