#include<cmath>
#include<iostream>
#include "Present_Value.h"
using namespace std;
Present_Value::Present_Value()
{
    cout<<" 1. For Present value \n 2. Present Value of Ordinary Annity \n 3. Present value of an Annuity due \n\t";
    cin>>s;
    switch (s)
    {
    case 1:
        cout<<"Enter the Future Value:"<<endl;
        cin>>fcv;
        cout<<"Enter the Number of years:"<<endl;
        cin>>N;
        cout<<"Enter the Discounting rate:"<<endl;
        cin>>I;
        ptv = fcv/(pow(((I/100)+1),N));
        cout<<"The present value is "<<ptv<<endl;
        break;

    //now to calculate the present value of ordinary annuity
    case 2:
        cout<<"Enter the Future Value:"<<endl;
        cin>>fcv;
        cout<<"Enter the Number of years:"<<endl;
        cin>>N;
        cout<<"Enter the Discounting rate:"<<endl;
        cin>>I;
        h = I/100;
        f = h+1;
        d = pow(f,-N);
        e = 1-d;
        g = e/h;
        ptv = fcv*g;
        cout<<"The present Value of Ordinary annuity is "<<ptv/10<<endl;
        break;
    //now to calculate the present value of annuity due
    case 3:
        cout<<"Enter the Future Value:"<<endl;
        cin>>fcv;
        cout<<"Enter the Number of years:"<<endl;
        cin>>N;
        cout<<"Enter the Discounting rate:"<<endl;
        cin>>I;
        h =I/100;
        f = h+1;
        d = pow(f,-N);
        e = 1-d;
        g = e/h;
        ptv = fcv*g*f;
        cout<<"The present Value of Annuity due is "<<ptv/10<<endl;
        break;
    default:
        cout<<"Enter a valid choice"<<endl;
        break;
    }
}
