#include "dep.h"
#include <iostream>
using namespace std;
//contructor of the class should have the same name as of the class
//has no datatype
future_amount::future_amount()
{
    cout << "ENTER THE FUTURE VALUE" << endl;
    cin >> fv;
}

interest_rat::interest_rat()
{
    cout << "WHAT IS THE INTEREST RATE" << endl;
    cin >> i;
}
periods::periods()
{
    cout << "ENTER NUMBER OF YEARS INVESTED" << endl;
    cin >> n;
}
