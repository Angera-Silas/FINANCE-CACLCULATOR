#ifndef FUTURE_VALUE_H_INCLUDED
#define FUTURE_VALUE_H_INCLUDED
class Future_Value
{
public:
    long psv;
    float r;
    float t,b,c;
    long ftv;
    int v;
    Future_Value();
private:

protected:

};


#endif // FUTURE_VALUE_H_INCLUDED
