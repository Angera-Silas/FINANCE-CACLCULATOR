#ifndef PV_H_INCLUDED
#define PV_H_INCLUDED
#include "dep.h"
class present_amount : public future_amount, public interest_rat, public periods
{
public:
    long pv,m;
    int opt;
    present_amount();
private:

protected:

};

#endif // PV_H_INCLUDED
