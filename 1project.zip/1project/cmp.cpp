#include "cmp.h"
#include <iostream>
using namespace std;
//contructor of the class should have the same name as of the class
//has no datatype
present_value::present_value()
{
    cout << "ENTER THE AMOUNT OF MONEY DEPOSITED" << endl;
    cin >> pv;
}

interest_rate::interest_rate()
{
    cout << "WHAT IS THE INTEREST RATE" << endl;
    cin >> i;
}
period::period()
{
    cout << "ENTER NUMBER OF YEARS INVESTED" << endl;
    cin >> n;
}
